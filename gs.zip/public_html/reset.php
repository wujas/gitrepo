<?php

echo sha1('moje-tajne-haslo');

?>

